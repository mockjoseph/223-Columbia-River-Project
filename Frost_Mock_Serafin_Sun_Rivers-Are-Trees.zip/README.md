# 223-Columbia-River-Project
Modeling the Columbia river as a binary tree.
Joseph Mock, Carson Frost, Charlie Serafin, Jessica Sun
